<?php

$_ENV['RAINLOOP_INCLUDE_AS_API'] = true;
include '/var/www/webmail.example.com/index.php';

$oConfig = \RainLoop\Api::Config();
$oConfig->SetPassword('your_secret_password');
echo $oConfig->Save() ? 'Done' : 'Error';

?>
